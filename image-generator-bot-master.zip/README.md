# Image Generator Discord Bot

## [VIDEO GUIDE](https://youtu.be/Nu-1o3rEDww)

## Technologies used:
- Node.js
- Discord.js
- Replicate
